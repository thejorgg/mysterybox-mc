data modify storage mysterybox:config loot_mode set value "godmode"
data modify storage mysterybox:config binding_curse set value 0
data modify storage mysterybox:config mending_basis_points set value 0
execute store result score #valid mbcheck run function mysterybox:reward/select_mode
execute unless score #valid mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute unless data storage mysterybox:runtime {loot_mode:"godmode",binding_curse:0,mending_basis_points:0} run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config loot_mode set value "default"
data modify storage mysterybox:config binding_curse set value 1
data modify storage mysterybox:config mending_basis_points set value 10000
data modify entity @e[type=item_display,tag=mbcheck.probe,limit=1] item set value {"id":"minecraft:netherite_chestplate","count":1}
function mysterybox:reward/prepare
scoreboard players add #samples mbcheck 1
execute unless data storage mysterybox:runtime reward{"id":"minecraft:netherite_chestplate","count":1} run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
function mbcheck:check/godmode/netherite_chestplate
data merge entity @e[type=item_display,tag=mbcheck.probe,limit=1] {item_display:"gui"}
function mysterybox:reward/visual
execute unless entity @e[type=item_display,tag=mbcheck.probe,nbt={item_display:"none"}] run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config loot_mode set value "extended"
function mysterybox:reward/drop
execute positioned ~ ~1.62 ~ run tag @e[type=item,tag=!mbcheck.drop,distance=..0.65] add mbcheck.drop
scoreboard players set #actual mbcheck 0
execute as @e[type=item,tag=mbcheck.drop,distance=..2] run scoreboard players add #actual mbcheck 1
execute unless score #actual mbcheck matches 1 run scoreboard players add #errors mbcheck 1
scoreboard players set #matched mbcheck 0
execute as @e[type=item,tag=mbcheck.drop,distance=..2,nbt={"Item":{"id":"minecraft:netherite_chestplate","count":1}}] run scoreboard players add #matched mbcheck 1
execute unless score #matched mbcheck matches 1 run scoreboard players add #errors mbcheck 1
scoreboard players set #changed mbcheck 0
execute store success score #changed mbcheck run data modify entity @e[type=item,tag=mbcheck.drop,distance=..2,nbt={"Item":{"id":"minecraft:netherite_chestplate","count":1}},limit=1] Item set from storage mysterybox:runtime reward
execute if score #changed mbcheck matches 1 run scoreboard players add #errors mbcheck 1
kill @e[type=item,tag=mbcheck.drop,distance=..2]
