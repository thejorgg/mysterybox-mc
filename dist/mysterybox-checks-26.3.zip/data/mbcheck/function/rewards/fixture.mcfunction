scoreboard objectives add mbcheck dummy
scoreboard players set #errors mbcheck 0
scoreboard players set #samples mbcheck 0
data modify storage mbcheck:state saved_config set from storage mysterybox:config
data modify storage mbcheck:state saved_runtime set from storage mysterybox:runtime
data modify storage mysterybox:config vanishing_curse set value 0
data modify storage mysterybox:config loot_mode set value "default"
data modify storage mysterybox:config binding_curse set value 1
data modify storage mysterybox:config mending_basis_points set value 670
execute store result score #valid mbcheck run function mysterybox:reward/select_mode
scoreboard players add #samples mbcheck 1
execute unless score #valid mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute unless data storage mysterybox:runtime {loot_mode:"combat",binding_curse:1,mending_basis_points:670} run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config loot_mode set value "invalid"
execute store result score #valid mbcheck run function mysterybox:reward/select_mode
scoreboard players add #samples mbcheck 1
execute unless score #valid mbcheck matches 0 run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config loot_mode set value "all"
data modify storage mysterybox:config teddy_basis_points set value 1000
data modify storage mysterybox:runtime loot_table set value "mysterybox:all_gear"
function mysterybox:config/loot_upgrade
scoreboard players add #samples mbcheck 1
execute unless data storage mysterybox:config {loot_mode:"default",teddy_basis_points:400} run scoreboard players add #errors mbcheck 1
execute unless data storage mysterybox:runtime {loot_table:"mysterybox:weapons_armor"} run scoreboard players add #errors mbcheck 1
execute store result score #valid mbcheck run function mysterybox:reward/select_mode
execute unless score #valid mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute unless data storage mysterybox:runtime {loot_mode:"combat"} run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
summon item_display ~ ~ ~ {Tags:["mysterybox.reward","mbcheck.probe"],item:{id:"minecraft:paper",count:1}}
function mbcheck:rewards/case/healing
function mbcheck:rewards/case/splash
function mbcheck:rewards/case/lingering
function mbcheck:rewards/case/shulker
function mbcheck:rewards/case/bow
function mbcheck:rewards/case/crossbow
function mbcheck:rewards/case/trident
function mbcheck:rewards/case/tnt
function mbcheck:rewards/case/golden_apple
function mbcheck:rewards/case/bedrock
function mbcheck:rewards/case/godmode_netherite_sword
function mbcheck:rewards/case/godmode_netherite_chestplate
function mbcheck:rewards/case/godmode_netherite_pickaxe
function mbcheck:rewards/case/godmode_netherite_axe
function mbcheck:rewards/case/godmode_crossbow
function mbcheck:rewards/case/godmode_trident
function mbcheck:rewards/case/godmode_brush
function mbcheck:rewards/case/cursed_healing
function mbcheck:rewards/case/cursed_bow
function mbcheck:rewards/case/cursed_tnt
function mbcheck:rewards/case/cursed_bedrock
function mbcheck:rewards/case/mending_bow
function mbcheck:rewards/case/mending_crossbow
function mbcheck:rewards/case/mending_pickaxe
function mbcheck:rewards/case/mending_brush
function mbcheck:rewards/case/mending_trident
function mbcheck:rewards/case/mending_potion
data modify storage mysterybox:config binding_curse set value 0
data modify storage mysterybox:config vanishing_curse set value 0
data modify storage mysterybox:config loot_mode set value "default"
function mysterybox:reward/select_mode
data modify storage mysterybox:config binding_curse set value 1
data modify storage mysterybox:config vanishing_curse set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:tnt 16
function mysterybox:reward/prepare
function mysterybox:reward/drop
execute positioned ~ ~1.62 ~ run tag @e[type=item,distance=..0.65] add mbcheck.drop
scoreboard players add #samples mbcheck 1
execute unless entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:tnt",count:16}},limit=1] run scoreboard players add #errors mbcheck 1
execute if data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:tnt",count:16}},limit=1] Item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute if data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:tnt",count:16}},limit=1] Item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
execute unless entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:flint_and_steel",count:1}},limit=1] run scoreboard players add #errors mbcheck 1
execute if data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:flint_and_steel",count:1}},limit=1] Item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute if data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:flint_and_steel",count:1}},limit=1] Item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
kill @e[type=item,tag=mbcheck.drop]
data modify storage mysterybox:config binding_curse set value 0
data modify storage mysterybox:config vanishing_curse set value 1
data modify storage mysterybox:config loot_mode set value "default"
function mysterybox:reward/select_mode
data modify storage mysterybox:config binding_curse set value 1
data modify storage mysterybox:config vanishing_curse set value 0
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:tnt 16
function mysterybox:reward/prepare
function mysterybox:reward/drop
execute positioned ~ ~1.62 ~ run tag @e[type=item,distance=..0.65] add mbcheck.drop
scoreboard players add #samples mbcheck 1
execute unless entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:tnt",count:16}},limit=1] run scoreboard players add #errors mbcheck 1
execute if data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:tnt",count:16}},limit=1] Item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute unless data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:tnt",count:16}},limit=1] Item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
execute unless entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:flint_and_steel",count:1}},limit=1] run scoreboard players add #errors mbcheck 1
execute if data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:flint_and_steel",count:1}},limit=1] Item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute unless data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:flint_and_steel",count:1}},limit=1] Item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
kill @e[type=item,tag=mbcheck.drop]
data modify storage mysterybox:config binding_curse set value 1
data modify storage mysterybox:config vanishing_curse set value 0
data modify storage mysterybox:config loot_mode set value "default"
function mysterybox:reward/select_mode
data modify storage mysterybox:config binding_curse set value 0
data modify storage mysterybox:config vanishing_curse set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:tnt 16
function mysterybox:reward/prepare
function mysterybox:reward/drop
execute positioned ~ ~1.62 ~ run tag @e[type=item,distance=..0.65] add mbcheck.drop
scoreboard players add #samples mbcheck 1
execute unless entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:tnt",count:16}},limit=1] run scoreboard players add #errors mbcheck 1
execute unless data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:tnt",count:16}},limit=1] Item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute if data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:tnt",count:16}},limit=1] Item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
execute unless entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:flint_and_steel",count:1}},limit=1] run scoreboard players add #errors mbcheck 1
execute unless data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:flint_and_steel",count:1}},limit=1] Item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute if data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:flint_and_steel",count:1}},limit=1] Item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
kill @e[type=item,tag=mbcheck.drop]
data modify storage mysterybox:config binding_curse set value 1
data modify storage mysterybox:config vanishing_curse set value 1
data modify storage mysterybox:config loot_mode set value "default"
function mysterybox:reward/select_mode
data modify storage mysterybox:config binding_curse set value 0
data modify storage mysterybox:config vanishing_curse set value 0
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:tnt 16
function mysterybox:reward/prepare
function mysterybox:reward/drop
execute positioned ~ ~1.62 ~ run tag @e[type=item,distance=..0.65] add mbcheck.drop
scoreboard players add #samples mbcheck 1
execute unless entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:tnt",count:16}},limit=1] run scoreboard players add #errors mbcheck 1
execute unless data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:tnt",count:16}},limit=1] Item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute unless data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:tnt",count:16}},limit=1] Item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
execute unless entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:flint_and_steel",count:1}},limit=1] run scoreboard players add #errors mbcheck 1
execute unless data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:flint_and_steel",count:1}},limit=1] Item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute unless data entity @e[type=item,tag=mbcheck.drop,nbt={Item:{id:"minecraft:flint_and_steel",count:1}},limit=1] Item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
kill @e[type=item,tag=mbcheck.drop]
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_helmet
scoreboard players set #binding_roll mb 200
scoreboard players set #vanishing_roll mb 201
function mysterybox:reward/random_curses
scoreboard players add #samples mbcheck 1
execute unless data entity @e[tag=mbcheck.probe,limit=1] item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute if data entity @e[tag=mbcheck.probe,limit=1] item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_helmet
scoreboard players set #binding_roll mb 201
scoreboard players set #vanishing_roll mb 200
function mysterybox:reward/random_curses
scoreboard players add #samples mbcheck 1
execute if data entity @e[tag=mbcheck.probe,limit=1] item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute unless data entity @e[tag=mbcheck.probe,limit=1] item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_helmet
scoreboard players set #binding_roll mb 200
scoreboard players set #vanishing_roll mb 200
function mysterybox:reward/random_curses
scoreboard players add #samples mbcheck 1
execute unless data entity @e[tag=mbcheck.probe,limit=1] item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute unless data entity @e[tag=mbcheck.probe,limit=1] item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_helmet
scoreboard players set #binding_roll mb 201
scoreboard players set #vanishing_roll mb 201
function mysterybox:reward/random_curses
scoreboard players add #samples mbcheck 1
execute if data entity @e[tag=mbcheck.probe,limit=1] item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute if data entity @e[tag=mbcheck.probe,limit=1] item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_sword
scoreboard players set #binding_roll mb 200
scoreboard players set #vanishing_roll mb 200
function mysterybox:reward/random_curses
scoreboard players add #samples mbcheck 1
execute if data entity @e[tag=mbcheck.probe,limit=1] item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute unless data entity @e[tag=mbcheck.probe,limit=1] item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:potion
scoreboard players set #binding_roll mb 200
scoreboard players set #vanishing_roll mb 200
function mysterybox:reward/random_curses
scoreboard players add #samples mbcheck 1
execute if data entity @e[tag=mbcheck.probe,limit=1] item.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute if data entity @e[tag=mbcheck.probe,limit=1] item.components."minecraft:enchantments"."minecraft:vanishing_curse" run scoreboard players add #errors mbcheck 1
kill @e[type=item_display,tag=mbcheck.probe]
execute if data storage mbcheck:state saved_runtime.loot_mode run data modify storage mysterybox:runtime loot_mode set from storage mbcheck:state saved_runtime.loot_mode
execute unless data storage mbcheck:state saved_runtime.loot_mode run data remove storage mysterybox:runtime loot_mode
execute if data storage mbcheck:state saved_runtime.reward run data modify storage mysterybox:runtime reward set from storage mbcheck:state saved_runtime.reward
execute unless data storage mbcheck:state saved_runtime.reward run data remove storage mysterybox:runtime reward
execute if data storage mbcheck:state saved_runtime.loot_table run data modify storage mysterybox:runtime loot_table set from storage mbcheck:state saved_runtime.loot_table
execute unless data storage mbcheck:state saved_runtime.loot_table run data remove storage mysterybox:runtime loot_table
execute if data storage mbcheck:state saved_runtime.loot_sets_v1 run data modify storage mysterybox:runtime loot_sets_v1 set from storage mbcheck:state saved_runtime.loot_sets_v1
execute unless data storage mbcheck:state saved_runtime.loot_sets_v1 run data remove storage mysterybox:runtime loot_sets_v1
execute if data storage mbcheck:state saved_runtime.binding_curse run data modify storage mysterybox:runtime binding_curse set from storage mbcheck:state saved_runtime.binding_curse
execute unless data storage mbcheck:state saved_runtime.binding_curse run data remove storage mysterybox:runtime binding_curse
execute if data storage mbcheck:state saved_runtime.vanishing_curse run data modify storage mysterybox:runtime vanishing_curse set from storage mbcheck:state saved_runtime.vanishing_curse
execute unless data storage mbcheck:state saved_runtime.vanishing_curse run data remove storage mysterybox:runtime vanishing_curse
execute if data storage mbcheck:state saved_runtime.mending_basis_points run data modify storage mysterybox:runtime mending_basis_points set from storage mbcheck:state saved_runtime.mending_basis_points
execute unless data storage mbcheck:state saved_runtime.mending_basis_points run data remove storage mysterybox:runtime mending_basis_points
data modify storage mysterybox:config price_points set from storage mbcheck:state saved_config.price_points
data modify storage mysterybox:config teddy_basis_points set from storage mbcheck:state saved_config.teddy_basis_points
data modify storage mysterybox:config relocate set from storage mbcheck:state saved_config.relocate
data modify storage mysterybox:config placement set from storage mbcheck:state saved_config.placement
data modify storage mysterybox:config loot_mode set from storage mbcheck:state saved_config.loot_mode
data modify storage mysterybox:config binding_curse set from storage mbcheck:state saved_config.binding_curse
data modify storage mysterybox:config vanishing_curse set from storage mbcheck:state saved_config.vanishing_curse
data modify storage mysterybox:config mending_basis_points set from storage mbcheck:state saved_config.mending_basis_points
data modify storage mysterybox:config enchant_level_min set from storage mbcheck:state saved_config.enchant_level_min
data modify storage mysterybox:config enchant_level_max set from storage mbcheck:state saved_config.enchant_level_max
data modify storage mysterybox:config opening_sound set from storage mbcheck:state saved_config.opening_sound
data modify storage mysterybox:config closing_sound set from storage mbcheck:state saved_config.closing_sound
data modify storage mysterybox:config teddy_sound set from storage mbcheck:state saved_config.teddy_sound
data modify storage mysterybox:config dragon_sound set from storage mbcheck:state saved_config.dragon_sound
data modify storage mysterybox:config moving_sound set from storage mbcheck:state saved_config.moving_sound
data modify storage mysterybox:config melody set from storage mbcheck:state saved_config.melody
data modify storage mysterybox:config melody_volume set from storage mbcheck:state saved_config.melody_volume
data modify storage mysterybox:config finished_volume set from storage mbcheck:state saved_config.finished_volume
data modify storage mysterybox:config teddy_volume set from storage mbcheck:state saved_config.teddy_volume
data modify storage mysterybox:config dragon_volume set from storage mbcheck:state saved_config.dragon_volume
data modify storage mysterybox:config opening_volume set from storage mbcheck:state saved_config.opening_volume
data modify storage mysterybox:config closing_volume set from storage mbcheck:state saved_config.closing_volume
data modify storage mysterybox:config moving_volume set from storage mbcheck:state saved_config.moving_volume
data modify storage mbcheck:results reward_status set value "completed"
execute store result storage mbcheck:results reward_errors int 1 run scoreboard players get #errors mbcheck
execute store result storage mbcheck:results reward_samples int 1 run scoreboard players get #samples mbcheck
tellraw @a [{"text":"Reward checks: "},{"score":{"name":"#errors","objective":"mbcheck"}},{"text":" errors / "},{"score":{"name":"#samples","objective":"mbcheck"}},{"text":" samples"}]
