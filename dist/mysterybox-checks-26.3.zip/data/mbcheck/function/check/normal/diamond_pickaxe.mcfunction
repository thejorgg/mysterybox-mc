scoreboard players add #samples mbcheck 1
execute unless data storage mysterybox:runtime reward{id:"minecraft:diamond_pickaxe",count:1} run scoreboard players add #errors mbcheck 1
execute store result score #count mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"
execute unless score #count mbcheck matches 1.. run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:aqua_affinity" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:aqua_affinity"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:aqua_affinity" unless score #level mbcheck matches 1..1 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:bane_of_arthropods" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:bane_of_arthropods"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:bane_of_arthropods" unless score #level mbcheck matches 1..5 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:binding_curse" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:binding_curse"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:binding_curse" unless score #level mbcheck matches 1..1 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:blast_protection" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:blast_protection"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:blast_protection" unless score #level mbcheck matches 1..4 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:breach" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:breach"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:breach" unless score #level mbcheck matches 1..4 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:channeling" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:channeling"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:channeling" unless score #level mbcheck matches 1..1 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:density" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:density"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:density" unless score #level mbcheck matches 1..5 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:depth_strider" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:depth_strider"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:depth_strider" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:efficiency"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:efficiency" unless score #level mbcheck matches 1..5 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:feather_falling" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:feather_falling"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:feather_falling" unless score #level mbcheck matches 1..4 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:fire_aspect" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:fire_aspect"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:fire_aspect" unless score #level mbcheck matches 1..2 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:fire_protection" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:fire_protection"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:fire_protection" unless score #level mbcheck matches 1..4 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:flame" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:flame"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:flame" unless score #level mbcheck matches 1..1 run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:fortune"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:fortune" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:frost_walker" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:frost_walker"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:frost_walker" unless score #level mbcheck matches 1..2 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:impaling" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:impaling"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:impaling" unless score #level mbcheck matches 1..5 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:infinity" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:infinity"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:infinity" unless score #level mbcheck matches 1..1 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:knockback" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:knockback"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:knockback" unless score #level mbcheck matches 1..2 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:looting" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:looting"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:looting" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:loyalty" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:loyalty"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:loyalty" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:luck_of_the_sea" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:luck_of_the_sea"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:luck_of_the_sea" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:lunge" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:lunge"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:lunge" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:lure" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:lure"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:lure" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" unless score #level mbcheck matches 1..1 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:multishot" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:multishot"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:multishot" unless score #level mbcheck matches 1..1 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:piercing" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:piercing"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:piercing" unless score #level mbcheck matches 1..4 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:power" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:power"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:power" unless score #level mbcheck matches 1..5 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:projectile_protection" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:projectile_protection"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:projectile_protection" unless score #level mbcheck matches 1..4 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:protection" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:protection"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:protection" unless score #level mbcheck matches 1..4 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:punch" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:punch"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:punch" unless score #level mbcheck matches 1..2 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:quick_charge" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:quick_charge"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:quick_charge" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:respiration" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:respiration"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:respiration" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:riptide" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:riptide"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:riptide" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:sharpness" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:sharpness"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:sharpness" unless score #level mbcheck matches 1..5 run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:silk_touch"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:silk_touch" unless score #level mbcheck matches 1..1 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:smite" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:smite"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:smite" unless score #level mbcheck matches 1..5 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:soul_speed" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:soul_speed"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:soul_speed" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:sweeping_edge" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:sweeping_edge"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:sweeping_edge" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:swift_sneak" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:swift_sneak"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:swift_sneak" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:thorns" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:thorns"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:thorns" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:unbreaking"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:unbreaking" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:vanishing_curse"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:vanishing_curse" unless score #level mbcheck matches 1..1 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:wind_burst" run scoreboard players add #errors mbcheck 1
execute store result score #level mbcheck run data get storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:wind_burst"
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:wind_burst" unless score #level mbcheck matches 1..3 run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:bane_of_arthropods" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:breach" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:bane_of_arthropods" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:density" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:bane_of_arthropods" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:impaling" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:bane_of_arthropods" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:sharpness" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:bane_of_arthropods" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:smite" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:blast_protection" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:fire_protection" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:blast_protection" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:projectile_protection" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:blast_protection" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:protection" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:breach" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:density" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:breach" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:impaling" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:breach" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:sharpness" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:breach" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:smite" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:channeling" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:riptide" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:density" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:impaling" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:density" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:sharpness" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:density" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:smite" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:depth_strider" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:frost_walker" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:fire_protection" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:projectile_protection" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:fire_protection" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:protection" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:fortune" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:silk_touch" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:impaling" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:sharpness" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:impaling" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:smite" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:infinity" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:loyalty" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:riptide" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:multishot" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:piercing" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:projectile_protection" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:protection" run scoreboard players add #errors mbcheck 1
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:sharpness" if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:smite" run scoreboard players add #errors mbcheck 1
