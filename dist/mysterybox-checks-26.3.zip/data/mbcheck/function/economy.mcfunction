execute unless score #state mb matches 0 run return run tellraw @s {"text":"Wait for an idle mystery box before testing.","color":"red"}
execute unless entity @e[tag=mysterybox.anchor,limit=1] run return run tellraw @s {"text":"Place a mystery box before testing.","color":"red"}
execute if entity @e[tag=mysterybox.reward] run return run tellraw @s {"text":"Wait until the reward display clears before testing.","color":"red"}
scoreboard objectives add mbcheck dummy
scoreboard players set #errors mbcheck 0
data modify storage mbcheck:state saved_config set from storage mysterybox:config
execute if score @s mb_xp_credit matches 1.. run return run tellraw @s {"text":"Wait for your pending teddy refund before testing.","color":"red"}
execute if score @s mb_xp_pt_credit matches 1.. run return run tellraw @s {"text":"Wait for your pending teddy refund before testing.","color":"red"}
execute store result storage mbcheck:state saved_xp.levels int 1 run experience query @s levels
execute store result storage mbcheck:state saved_xp.points int 1 run experience query @s points
data modify storage mysterybox:config teddy_basis_points set value 0
data modify storage mysterybox:config price_points set value 95
item replace entity @s weapon.mainhand with minecraft:stone
item replace entity @s weapon.offhand with minecraft:air
experience set @s 7 levels
experience set @s 3 points
execute at @e[tag=mysterybox.anchor,limit=1] run function mysterybox:purchase
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 7 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 3 run scoreboard players add #errors mbcheck 1
execute unless score #state mb matches 0 run scoreboard players add #errors mbcheck 1
experience set @s 30 levels
experience set @s 37 points
execute at @e[tag=mysterybox.anchor,limit=1] run function mysterybox:purchase
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 29 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 49 run scoreboard players add #errors mbcheck 1
execute unless items entity @s weapon.mainhand minecraft:stone run scoreboard players add #errors mbcheck 1
execute unless score #state mb matches 1 run scoreboard players add #errors mbcheck 1
execute at @e[tag=mysterybox.anchor,limit=1] run function mysterybox:purchase
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 29 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 49 run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:runtime reward set value {id:"minecraft:stone",count:1}
execute at @e[tag=mysterybox.anchor,limit=1] store result score #before mbcheck run execute if entity @e[type=item,distance=..8]
execute at @e[tag=mysterybox.anchor,limit=1] run function mysterybox:box/finish
execute at @e[tag=mysterybox.anchor,limit=1] store result score #after mbcheck run execute if entity @e[type=item,distance=..8]
scoreboard players operation #after mbcheck -= #before mbcheck
execute unless score #after mbcheck matches 1 run scoreboard players add #errors mbcheck 1
scoreboard players set #timer mb 20
execute at @e[tag=mysterybox.anchor,limit=1] run function mysterybox:box/close_tick
execute unless score #state mb matches 0 run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config teddy_basis_points set value 10000
data modify storage mysterybox:config relocate set value 1
experience set @s 30 levels
experience set @s 37 points
item replace entity @s weapon.mainhand with minecraft:air
execute at @e[tag=mysterybox.anchor,limit=1] run function mysterybox:purchase
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 29 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 49 run scoreboard players add #errors mbcheck 1
execute unless score #bear mb matches 1 run scoreboard players add #errors mbcheck 1
execute unless data storage mysterybox:runtime reward.components{"minecraft:item_model":"mysterybox:teddy"} run scoreboard players add #errors mbcheck 1
execute unless score @s mb_xp_pt_credit matches 95 run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config price_points set value 7
function mysterybox:economy/tick
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 29 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 49 run scoreboard players add #errors mbcheck 1
scoreboard players operation @s mb_xp_due = #xp_clock mb
function mysterybox:economy/tick
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 30 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 37 run scoreboard players add #errors mbcheck 1
execute if score @s mb_xp_pt_credit matches 1.. run scoreboard players add #errors mbcheck 1
function mysterybox:economy/tick
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 30 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 37 run scoreboard players add #errors mbcheck 1
execute at @e[tag=mysterybox.anchor,limit=1] store result score #before mbcheck run execute if entity @e[type=item,distance=..8]
execute at @e[tag=mysterybox.anchor,limit=1] run function mysterybox:box/finish
execute at @e[tag=mysterybox.anchor,limit=1] store result score #after mbcheck run execute if entity @e[type=item,distance=..8]
execute unless score #after mbcheck = #before mbcheck run scoreboard players add #errors mbcheck 1
scoreboard players set #timer mb 20
execute at @e[tag=mysterybox.anchor,limit=1] run function mysterybox:box/close_tick
execute unless score #state mb matches 2 run scoreboard players add #errors mbcheck 1
scoreboard players set #state mb 0
scoreboard players set #phase mb 0
data modify storage mysterybox:config price_points set value 95
scoreboard players set #price mb 95
experience set @s 7 levels
experience set @s 4 points
execute store result score #can_pay mbcheck run function mysterybox:economy/check
execute unless score #can_pay mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute store result score #charged mbcheck run function mysterybox:economy/charge
execute unless score #charged mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 0 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 0 run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config price_points set value 394
scoreboard players set #price mb 394
experience set @s 16 levels
experience set @s 41 points
execute store result score #can_pay mbcheck run function mysterybox:economy/check
execute unless score #can_pay mbcheck matches 0 run scoreboard players add #errors mbcheck 1
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 16 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 41 run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config price_points set value 394
scoreboard players set #price mb 394
experience set @s 17 levels
experience set @s 0 points
execute store result score #can_pay mbcheck run function mysterybox:economy/check
execute unless score #can_pay mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute store result score #charged mbcheck run function mysterybox:economy/charge
execute unless score #charged mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 0 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 0 run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config price_points set value 1628
scoreboard players set #price mb 1628
experience set @s 31 levels
experience set @s 120 points
execute store result score #can_pay mbcheck run function mysterybox:economy/check
execute unless score #can_pay mbcheck matches 0 run scoreboard players add #errors mbcheck 1
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 31 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 120 run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config price_points set value 1628
scoreboard players set #price mb 1628
experience set @s 32 levels
experience set @s 0 points
execute store result score #can_pay mbcheck run function mysterybox:economy/check
execute unless score #can_pay mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute store result score #charged mbcheck run function mysterybox:economy/charge
execute unless score #charged mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 0 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 0 run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config price_points set value 95
scoreboard players set #price mb 95
experience set @s 10000 levels
experience set @s 1000 points
execute store result score #can_pay mbcheck run function mysterybox:economy/check
execute unless score #can_pay mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute store result score #charged mbcheck run function mysterybox:economy/charge
execute unless score #charged mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 10000 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 905 run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config price_points set value 2147483647
scoreboard players set #price mb 2147483647
experience set @s 21863 levels
experience set @s 75703 points
execute store result score #can_pay mbcheck run function mysterybox:economy/check
execute unless score #can_pay mbcheck matches 0 run scoreboard players add #errors mbcheck 1
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 21863 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 75703 run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config price_points set value 2147483647
scoreboard players set #price mb 2147483647
experience set @s 21863 levels
experience set @s 75704 points
execute store result score #can_pay mbcheck run function mysterybox:economy/check
execute unless score #can_pay mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 21863 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 75704 run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config price_points set value 2147483647
scoreboard players set #price mb 2147483647
experience set @s 21864 levels
experience set @s 0 points
execute store result score #can_pay mbcheck run function mysterybox:economy/check
execute unless score #can_pay mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 21864 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 0 run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config price_points set value 95
scoreboard players set #price mb 95
experience set @s 10 levels
experience set @s 12 points
scoreboard players set @s mb_xp_credit 7
scoreboard players operation @s mb_xp_due = #xp_clock mb
scoreboard players add @s mb_xp_due 4
function mysterybox:economy/tick
execute store result score #can_pay mbcheck run function mysterybox:economy/check
execute unless score #can_pay mbcheck matches 0 run scoreboard players add #errors mbcheck 1
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 10 run scoreboard players add #errors mbcheck 1
execute store result score #points mbcheck run experience query @s points
execute unless score #points mbcheck matches 12 run scoreboard players add #errors mbcheck 1
scoreboard players operation @s mb_xp_due = #xp_clock mb
function mysterybox:economy/tick
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 17 run scoreboard players add #errors mbcheck 1
execute if score @s mb_xp_credit matches 1.. run scoreboard players add #errors mbcheck 1
function mysterybox:economy/tick
execute store result score #levels mbcheck run experience query @s levels
execute unless score #levels mbcheck matches 17 run scoreboard players add #errors mbcheck 1
execute store result score #can_pay mbcheck run function mysterybox:economy/check
execute unless score #can_pay mbcheck matches 1 run scoreboard players add #errors mbcheck 1
execute store result storage mbcheck:results economy_errors int 1 run scoreboard players get #errors mbcheck
tellraw @s [{"text":"XP-point/duplicate-purchase/teddy-refund checks: "},{"score":{"name":"#errors","objective":"mbcheck"}},{"text":" errors"}]
data modify storage mysterybox:config price_points set from storage mbcheck:state saved_config.price_points
data modify storage mysterybox:config teddy_basis_points set from storage mbcheck:state saved_config.teddy_basis_points
data modify storage mysterybox:config relocate set from storage mbcheck:state saved_config.relocate
data modify storage mysterybox:config placement set from storage mbcheck:state saved_config.placement
data modify storage mysterybox:config loot_mode set from storage mbcheck:state saved_config.loot_mode
data modify storage mysterybox:config binding_curse set from storage mbcheck:state saved_config.binding_curse
data modify storage mysterybox:config vanishing_curse set from storage mbcheck:state saved_config.vanishing_curse
data modify storage mysterybox:config mending_basis_points set from storage mbcheck:state saved_config.mending_basis_points
data modify storage mysterybox:config enchant_level_min set from storage mbcheck:state saved_config.enchant_level_min
data modify storage mysterybox:config enchant_level_max set from storage mbcheck:state saved_config.enchant_level_max
data modify storage mysterybox:config opening_sound set from storage mbcheck:state saved_config.opening_sound
data modify storage mysterybox:config closing_sound set from storage mbcheck:state saved_config.closing_sound
data modify storage mysterybox:config teddy_sound set from storage mbcheck:state saved_config.teddy_sound
data modify storage mysterybox:config dragon_sound set from storage mbcheck:state saved_config.dragon_sound
data modify storage mysterybox:config moving_sound set from storage mbcheck:state saved_config.moving_sound
data modify storage mysterybox:config melody set from storage mbcheck:state saved_config.melody
data modify storage mysterybox:config melody_volume set from storage mbcheck:state saved_config.melody_volume
data modify storage mysterybox:config finished_volume set from storage mbcheck:state saved_config.finished_volume
data modify storage mysterybox:config teddy_volume set from storage mbcheck:state saved_config.teddy_volume
data modify storage mysterybox:config dragon_volume set from storage mbcheck:state saved_config.dragon_volume
data modify storage mysterybox:config opening_volume set from storage mbcheck:state saved_config.opening_volume
data modify storage mysterybox:config closing_volume set from storage mbcheck:state saved_config.closing_volume
data modify storage mysterybox:config moving_volume set from storage mbcheck:state saved_config.moving_volume
function mbcheck:restore_xp with storage mbcheck:state saved_xp
