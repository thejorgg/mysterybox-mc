data modify storage mbcheck:results reward_status set value "refused"
data modify storage mbcheck:results reward_errors set value -1
data modify storage mbcheck:results reward_samples set value 0
execute unless score #state mb matches 0 run return run say Mystery box must be idle for reward checks
execute unless entity @e[tag=mysterybox.anchor,limit=1] run return run say Place a mystery box before reward checks
execute if entity @e[tag=mysterybox.reward] run return run say A reward display is already active
execute at @e[tag=mysterybox.anchor,limit=1] positioned ~ ~1.62 ~ if entity @e[type=item,distance=..2] run return run say Clear item entities near the mystery box before reward checks
execute at @e[tag=mysterybox.anchor,limit=1] if entity @e[type=minecraft:shulker,distance=..3] run return run say Clear shulkers near the mystery box before reward checks
execute at @e[tag=mysterybox.anchor,limit=1] run function mbcheck:rewards/fixture
