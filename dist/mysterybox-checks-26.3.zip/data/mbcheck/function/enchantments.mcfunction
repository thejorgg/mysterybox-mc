execute unless score #state mb matches 0 run return run tellraw @s {"text":"Wait for an idle mystery box before testing.","color":"red"}
execute unless entity @e[tag=mysterybox.anchor,limit=1] run return run tellraw @s {"text":"Place a mystery box before testing.","color":"red"}
execute if entity @e[tag=mysterybox.reward] run return run tellraw @s {"text":"Wait until the reward display clears before testing.","color":"red"}
scoreboard objectives add mbcheck dummy
scoreboard players set #errors mbcheck 0
data modify storage mbcheck:state saved_config set from storage mysterybox:config
scoreboard players set #samples mbcheck 0
data modify storage mbcheck:state saved_runtime set from storage mysterybox:runtime
data modify storage mysterybox:runtime loot_mode set value "combat"
data modify storage mysterybox:runtime binding_curse set value 0
data modify storage mysterybox:runtime vanishing_curse set value 0
data modify storage mysterybox:runtime mending_basis_points set value 0
summon item_display ~ ~ ~ {Tags:["mysterybox.reward","mbcheck.probe"],item:{id:"minecraft:paper",count:1}}
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:bow
function mysterybox:reward/prepare
function mbcheck:check/normal/bow
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:crossbow
function mysterybox:reward/prepare
function mbcheck:check/normal/crossbow
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:mace
function mysterybox:reward/prepare
function mbcheck:check/normal/mace
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:stone_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/stone_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:stone_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/stone_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:stone_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/stone_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:trident
function mysterybox:reward/prepare
function mbcheck:check/normal/trident
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:wooden_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/wooden_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:wooden_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/wooden_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:wooden_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/wooden_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:chainmail_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/chainmail_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:chainmail_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/chainmail_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:chainmail_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/chainmail_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:chainmail_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/chainmail_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:elytra
function mysterybox:reward/prepare
function mbcheck:check/normal/elytra
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:leather_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/leather_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:leather_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/leather_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:leather_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/leather_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:leather_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/leather_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:turtle_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/turtle_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:brush
function mysterybox:reward/prepare
function mbcheck:check/normal/brush
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:fishing_rod
function mysterybox:reward/prepare
function mbcheck:check/normal/fishing_rod
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:flint_and_steel
function mysterybox:reward/prepare
function mbcheck:check/normal/flint_and_steel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:shears
function mysterybox:reward/prepare
function mbcheck:check/normal/shears
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:stone_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/stone_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:stone_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/stone_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:stone_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/stone_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:wooden_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/wooden_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:wooden_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/wooden_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 1
data modify storage mysterybox:config enchant_level_max set value 1
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:wooden_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/wooden_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:bow
function mysterybox:reward/prepare
function mbcheck:check/normal/bow
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:crossbow
function mysterybox:reward/prepare
function mbcheck:check/normal/crossbow
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:mace
function mysterybox:reward/prepare
function mbcheck:check/normal/mace
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:stone_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/stone_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:stone_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/stone_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:stone_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/stone_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:trident
function mysterybox:reward/prepare
function mbcheck:check/normal/trident
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:wooden_axe
function mysterybox:reward/prepare
function mbcheck:check/normal/wooden_axe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:wooden_spear
function mysterybox:reward/prepare
function mbcheck:check/normal/wooden_spear
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:wooden_sword
function mysterybox:reward/prepare
function mbcheck:check/normal/wooden_sword
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:chainmail_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/chainmail_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:chainmail_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/chainmail_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:chainmail_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/chainmail_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:chainmail_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/chainmail_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:elytra
function mysterybox:reward/prepare
function mbcheck:check/normal/elytra
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:leather_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/leather_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:leather_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/leather_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:leather_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/leather_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:leather_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/leather_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_boots
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_boots
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_chestplate
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_chestplate
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_leggings
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_leggings
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:turtle_helmet
function mysterybox:reward/prepare
function mbcheck:check/normal/turtle_helmet
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:brush
function mysterybox:reward/prepare
function mbcheck:check/normal/brush
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:copper_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/copper_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:diamond_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/diamond_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:fishing_rod
function mysterybox:reward/prepare
function mbcheck:check/normal/fishing_rod
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:flint_and_steel
function mysterybox:reward/prepare
function mbcheck:check/normal/flint_and_steel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:golden_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/golden_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:iron_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/iron_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:netherite_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/netherite_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:shears
function mysterybox:reward/prepare
function mbcheck:check/normal/shears
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:stone_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/stone_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:stone_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/stone_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:stone_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/stone_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:wooden_hoe
function mysterybox:reward/prepare
function mbcheck:check/normal/wooden_hoe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:wooden_pickaxe
function mysterybox:reward/prepare
function mbcheck:check/normal/wooden_pickaxe
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config enchant_level_min set value 30
data modify storage mysterybox:config enchant_level_max set value 30
item replace entity @e[tag=mbcheck.probe,limit=1] contents with minecraft:wooden_shovel
function mysterybox:reward/prepare
function mbcheck:check/normal/wooden_shovel
execute if data storage mysterybox:runtime reward.components."minecraft:enchantments"."minecraft:mending" run scoreboard players add #errors mbcheck 1
data modify storage mysterybox:config price_points set from storage mbcheck:state saved_config.price_points
data modify storage mysterybox:config teddy_basis_points set from storage mbcheck:state saved_config.teddy_basis_points
data modify storage mysterybox:config relocate set from storage mbcheck:state saved_config.relocate
data modify storage mysterybox:config placement set from storage mbcheck:state saved_config.placement
data modify storage mysterybox:config loot_mode set from storage mbcheck:state saved_config.loot_mode
data modify storage mysterybox:config binding_curse set from storage mbcheck:state saved_config.binding_curse
data modify storage mysterybox:config vanishing_curse set from storage mbcheck:state saved_config.vanishing_curse
data modify storage mysterybox:config mending_basis_points set from storage mbcheck:state saved_config.mending_basis_points
data modify storage mysterybox:config enchant_level_min set from storage mbcheck:state saved_config.enchant_level_min
data modify storage mysterybox:config enchant_level_max set from storage mbcheck:state saved_config.enchant_level_max
data modify storage mysterybox:config opening_sound set from storage mbcheck:state saved_config.opening_sound
data modify storage mysterybox:config closing_sound set from storage mbcheck:state saved_config.closing_sound
data modify storage mysterybox:config teddy_sound set from storage mbcheck:state saved_config.teddy_sound
data modify storage mysterybox:config dragon_sound set from storage mbcheck:state saved_config.dragon_sound
data modify storage mysterybox:config moving_sound set from storage mbcheck:state saved_config.moving_sound
data modify storage mysterybox:config melody set from storage mbcheck:state saved_config.melody
data modify storage mysterybox:config melody_volume set from storage mbcheck:state saved_config.melody_volume
data modify storage mysterybox:config finished_volume set from storage mbcheck:state saved_config.finished_volume
data modify storage mysterybox:config teddy_volume set from storage mbcheck:state saved_config.teddy_volume
data modify storage mysterybox:config dragon_volume set from storage mbcheck:state saved_config.dragon_volume
data modify storage mysterybox:config opening_volume set from storage mbcheck:state saved_config.opening_volume
data modify storage mysterybox:config closing_volume set from storage mbcheck:state saved_config.closing_volume
data modify storage mysterybox:config moving_volume set from storage mbcheck:state saved_config.moving_volume
kill @e[tag=mbcheck.probe]
execute if data storage mbcheck:state saved_runtime.loot_mode run data modify storage mysterybox:runtime loot_mode set from storage mbcheck:state saved_runtime.loot_mode
execute unless data storage mbcheck:state saved_runtime.loot_mode run data remove storage mysterybox:runtime loot_mode
execute if data storage mbcheck:state saved_runtime.reward run data modify storage mysterybox:runtime reward set from storage mbcheck:state saved_runtime.reward
execute unless data storage mbcheck:state saved_runtime.reward run data remove storage mysterybox:runtime reward
execute if data storage mbcheck:state saved_runtime.loot_table run data modify storage mysterybox:runtime loot_table set from storage mbcheck:state saved_runtime.loot_table
execute unless data storage mbcheck:state saved_runtime.loot_table run data remove storage mysterybox:runtime loot_table
execute if data storage mbcheck:state saved_runtime.loot_sets_v1 run data modify storage mysterybox:runtime loot_sets_v1 set from storage mbcheck:state saved_runtime.loot_sets_v1
execute unless data storage mbcheck:state saved_runtime.loot_sets_v1 run data remove storage mysterybox:runtime loot_sets_v1
execute if data storage mbcheck:state saved_runtime.binding_curse run data modify storage mysterybox:runtime binding_curse set from storage mbcheck:state saved_runtime.binding_curse
execute unless data storage mbcheck:state saved_runtime.binding_curse run data remove storage mysterybox:runtime binding_curse
execute if data storage mbcheck:state saved_runtime.vanishing_curse run data modify storage mysterybox:runtime vanishing_curse set from storage mbcheck:state saved_runtime.vanishing_curse
execute unless data storage mbcheck:state saved_runtime.vanishing_curse run data remove storage mysterybox:runtime vanishing_curse
execute if data storage mbcheck:state saved_runtime.mending_basis_points run data modify storage mysterybox:runtime mending_basis_points set from storage mbcheck:state saved_runtime.mending_basis_points
execute unless data storage mbcheck:state saved_runtime.mending_basis_points run data remove storage mysterybox:runtime mending_basis_points
execute store result storage mbcheck:results enchantment_errors int 1 run scoreboard players get #errors mbcheck
execute store result storage mbcheck:results enchantment_samples int 1 run scoreboard players get #samples mbcheck
tellraw @s [{"text":"Enchantment checks: "},{"score":{"name":"#errors","objective":"mbcheck"}},{"text":" errors / "},{"score":{"name":"#samples","objective":"mbcheck"}},{"text":" samples"}]
