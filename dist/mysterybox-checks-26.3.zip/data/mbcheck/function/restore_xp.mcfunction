$experience set @s $(levels) levels
$experience set @s $(points) points
