execute unless score #state mb matches 0 run return run tellraw @s {"text":"Wait for an idle mystery box before testing.","color":"red"}
execute unless entity @e[tag=mysterybox.anchor,limit=1] run return run tellraw @s {"text":"Place a mystery box before testing.","color":"red"}
execute if entity @e[tag=mysterybox.reward] run return run tellraw @s {"text":"Wait until the reward display clears before testing.","color":"red"}
scoreboard objectives add mbcheck dummy
scoreboard players set #errors mbcheck 0
data modify storage mbcheck:state saved_config set from storage mysterybox:config
execute store result storage mbcheck:state saved_mode int 1 run scoreboard players get #mode mb
scoreboard players set #mode mb 2
scoreboard players set #good mb 0
function mysterybox:placement/check
execute unless score #good mb matches 0 run scoreboard players add #errors mbcheck 1
fill ~-1 ~-1 ~ ~1 ~-1 ~ minecraft:stone
fill ~-1 ~ ~-1 ~1 ~1 ~-1 minecraft:stone
fill ~-1 ~ ~1 ~1 ~1 ~1 minecraft:stone
fill ~-1 ~2 ~ ~1 ~2 ~ minecraft:stone
scoreboard players set #mode mb 1
scoreboard players set #good mb 0
function mysterybox:placement/check
execute unless score #good mb matches 1 run scoreboard players add #errors mbcheck 1
setblock ~-1 ~-1 ~ minecraft:air
scoreboard players set #good mb 0
function mysterybox:placement/check
execute unless score #good mb matches 0 run scoreboard players add #errors mbcheck 1
setblock ~-1 ~-1 ~ minecraft:stone
setblock ~0 ~-1 ~ minecraft:air
scoreboard players set #good mb 0
function mysterybox:placement/check
execute unless score #good mb matches 0 run scoreboard players add #errors mbcheck 1
setblock ~0 ~-1 ~ minecraft:stone
setblock ~1 ~-1 ~ minecraft:air
scoreboard players set #good mb 0
function mysterybox:placement/check
execute unless score #good mb matches 0 run scoreboard players add #errors mbcheck 1
setblock ~1 ~-1 ~ minecraft:stone
setblock ~ ~0 ~ minecraft:stone
scoreboard players set #good mb 0
function mysterybox:placement/check
execute unless score #good mb matches 0 run scoreboard players add #errors mbcheck 1
setblock ~ ~0 ~ minecraft:air
setblock ~ ~1 ~ minecraft:stone
scoreboard players set #good mb 0
function mysterybox:placement/check
execute unless score #good mb matches 0 run scoreboard players add #errors mbcheck 1
setblock ~ ~1 ~ minecraft:air
fill ~-2 ~-1 ~-1 ~2 ~2 ~1 minecraft:air
execute store result score #mode mb run data get storage mbcheck:state saved_mode
scoreboard players set #good mb 0
execute store result storage mbcheck:results placement_errors int 1 run scoreboard players get #errors mbcheck
tellraw @s [{text:"Grounded 3x2 placement checks: "},{score:{name:"#errors",objective:"mbcheck"}},{text:" errors"}]
